VHDL
====

VHDL samples from school projects.


8bit-calculator
---------------

8-bit calculator controller.


Vending Machine (vending-machine)
---------------------------------

A vending machine controller with typical vending machine logic (e.g. checking
item cost, giving change, vending selected items).


IEEE 754 Multiplier (ieee-754-multiplier)
-----------------------------------------

Implements (most of) the logic required to implement a IEEE 754 multiplier
unit.
